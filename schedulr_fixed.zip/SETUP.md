# Schedulr — Setup Guide

## What you're deploying
A Progressive Web App (PWA) that works like a real app on your phone.
- Auto-syncs your sportsYou schedule via iCal
- Google Classroom integration (needs one-time setup below)
- Push notifications for reminders
- Works offline once installed

---

## Step 1 — Deploy to Vercel (free, ~5 minutes)

1. Go to https://github.com and create a free account if you don't have one
2. Create a new repository called **schedulr** and upload all the files in this zip
3. Go to https://vercel.com and sign up with your GitHub account
4. Click **"Add New Project"** → import your **schedulr** repo
5. Click **Deploy** — Vercel will give you a URL like `https://schedulr-abc123.vercel.app`

---

## Step 2 — Install on your phone

**iPhone:**
1. Open Safari and go to your Vercel URL
2. Tap the Share button (box with arrow pointing up)
3. Tap **"Add to Home Screen"**
4. Tap **Add** — it will appear as an app icon on your home screen!

**Android:**
1. Open Chrome and go to your Vercel URL
2. Tap the three-dot menu (top right)
3. Tap **"Add to Home screen"**
4. Tap **Add**

---

## Step 3 — Connect sportsYou

1. Open the **sportsYou** app on your phone
2. Tap **Calendar** in the bottom navigation
3. Tap the **subscribe icon** in the top right corner
4. Tap **Copy Link**
5. Open Schedulr → tap ⚙ Settings → paste the link under **Connect Sports You**
6. Tap **Connect Sports You** — your games and practices will sync automatically!

---

## Step 4 — Connect Google Classroom (requires developer setup)

This requires a free Google Cloud account:

1. Go to https://console.cloud.google.com
2. Click **"Create Project"** → name it **Schedulr**
3. In the search bar, search **"Google Classroom API"** → click **Enable**
4. Go to **Credentials** → click **"Create Credentials"** → **OAuth 2.0 Client ID**
5. Choose **Web Application**
6. Under "Authorized JavaScript Origins", add your Vercel URL (e.g. `https://schedulr-abc123.vercel.app`)
7. Click **Create** — copy the **Client ID**
8. Open `app.js` in your project, find the line that says:
   ```
   // const CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID';
   ```
9. Uncomment it and replace `YOUR_GOOGLE_CLIENT_ID` with your actual Client ID
10. Also uncomment the lines below it (the authUrl and window.location.href lines)
11. Redeploy to Vercel

---

## Step 5 — Enable Notifications

1. Open Schedulr on your phone
2. Tap ⚙ Settings
3. Tap **Enable Notifications** and allow when prompted
4. You'll get reminders based on the timing you set for each event

---

## Need help?
If you get stuck on any step, ask Claude — just describe where you are
and what you're seeing and it can walk you through it!
