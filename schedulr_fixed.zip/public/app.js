// ── Schedulr App ──────────────────────────────────────────────
const App = (() => {

  // ── State ──
  const today = new Date();
  let curYear = today.getFullYear();
  let curMonth = today.getMonth();
  let selectedDate = null;
  let userName = localStorage.getItem('schedulr_name') || '';
  let currentTheme = localStorage.getItem('schedulr_theme') || 'sky';
  let events = JSON.parse(localStorage.getItem('schedulr_events') || '[]');
  let nextId = parseInt(localStorage.getItem('schedulr_nextid') || '100');

  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const SHORT_MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  // ── Init ──
  function init() {
    // Restore theme
    applyTheme(currentTheme);

    // Restore name & show splash or app
    if (userName) {
      showApp();
    } else {
      document.getElementById('splash').classList.remove('hidden');
    }

    // Restore iCal url field
    const savedIcal = localStorage.getItem('schedulr_ical');
    if (savedIcal) document.getElementById('ical-url').value = savedIcal;

    // Restore custom color
    const savedColor = localStorage.getItem('schedulr_custom_color');
    if (savedColor) document.getElementById('custom-color').value = savedColor;

    // Check notification permission
    updateNotifButton();

    // Splash enter key
    document.getElementById('splash-name').addEventListener('keydown', e => {
      if (e.key === 'Enter') confirmName();
    });
  }

  // ── Name / Splash ──
  function confirmName(skip = false) {
    const input = document.getElementById('splash-name').value.trim();
    userName = (!skip && input) ? input : (userName || '');
    localStorage.setItem('schedulr_name', userName);
    document.getElementById('splash').classList.add('hidden');
    showApp();
  }

  function showApp() {
    document.getElementById('app').classList.remove('hidden');
    updateGreeting();
    renderCalendar();
  }

  function updateGreeting() {
    const h = today.getHours();
    const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
    const el = document.getElementById('greeting');
    el.textContent = userName ? `${greet}, ${userName}!` : 'My Schedule';
  }

  function reopenSplash() {
    document.getElementById('splash-name').value = userName;
    document.getElementById('splash').classList.remove('hidden');
  }

  // ── Themes ──
  const themes = {
    sky:      { dark: false },
    sunset:   { dark: false },
    ocean:    { dark: true  },
    forest:   { dark: false },
    candy:    { dark: false },
    midnight: { dark: true  },
    peach:    { dark: false },
    custom:   { dark: false },
  };

  function applyTheme(name) {
    document.body.className = `theme-${name}`;
    currentTheme = name;
    localStorage.setItem('schedulr_theme', name);
    document.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
    const active = document.querySelector(`.swatch[data-theme="${name}"]`);
    if (active) active.classList.add('active');
  }

  function setTheme(name, el) {
    applyTheme(name);
  }

  function setCustomColor(val) {
    localStorage.setItem('schedulr_custom_color', val);
    const c2 = shiftHue(val, 40), c3 = shiftHue(val, 80);
    document.documentElement.style.setProperty('--custom-bg',
      `linear-gradient(135deg,${val} 0%,${c2} 50%,${c3} 100%)`);
    applyTheme('custom');
    document.querySelector('.swatch-custom').classList.add('active');
    if (isDark(val)) document.body.classList.add('dark-custom');
    else document.body.classList.remove('dark-custom');
  }

  function shiftHue(hex, deg) {
    let r = parseInt(hex.slice(1,3),16)/255, g = parseInt(hex.slice(3,5),16)/255, b = parseInt(hex.slice(5,7),16)/255;
    const max = Math.max(r,g,b), min = Math.min(r,g,b), d = max-min;
    let h=0, s = max===0?0:d/max, v=max;
    if(d!==0){if(max===r)h=((g-b)/d+6)%6;else if(max===g)h=(b-r)/d+2;else h=(r-g)/d+4;h/=6;}
    h=(h+deg/360)%1;
    const i=Math.floor(h*6),f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);
    let nr,ng,nb;
    switch(i%6){case 0:nr=v;ng=t;nb=p;break;case 1:nr=q;ng=v;nb=p;break;case 2:nr=p;ng=v;nb=t;break;case 3:nr=p;ng=q;nb=v;break;case 4:nr=t;ng=p;nb=v;break;default:nr=v;ng=p;nb=q;}
    return '#'+[nr,ng,nb].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('');
  }

  function isDark(hex) {
    const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);
    return (r*299+g*587+b*114)/1000 < 128;
  }

  // ── Calendar ──
  function renderCalendar() {
    const grid = document.getElementById('cal-grid');
    Array.from(grid.children).forEach(c => { if (!c.classList.contains('day-hdr')) c.remove(); });

    document.getElementById('month-label').textContent = `${MONTHS[curMonth]} ${curYear}`;

    const first = new Date(curYear, curMonth, 1).getDay();
    const days  = new Date(curYear, curMonth+1, 0).getDate();
    const prev  = new Date(curYear, curMonth, 0).getDate();

    const evByDay = {};
    events.forEach(e => {
      const [ey,em,ed] = e.date.split('-').map(Number);
      if (ey===curYear && em-1===curMonth) {
        if (!evByDay[ed]) evByDay[ed] = [];
        evByDay[ed].push(e);
      }
    });

    // Prev month trailing
    for (let i=0; i<first; i++) {
      const c = document.createElement('div');
      c.className = 'day-cell other-month';
      c.innerHTML = `<div class="day-num">${prev-first+1+i}</div>`;
      grid.appendChild(c);
    }

    // Current month
    for (let d=1; d<=days; d++) {
      const cell = document.createElement('div');
      const isToday = d===today.getDate() && curMonth===today.getMonth() && curYear===today.getFullYear();
      cell.className = 'day-cell' + (isToday ? ' today' : '');
      const ds = `${curYear}-${String(curMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
      cell.innerHTML = `<div class="day-num">${d}</div>`;
      (evByDay[d]||[]).slice(0,2).forEach(e => {
        const dot = document.createElement('div');
        dot.className = `ev-dot ${e.cat}`;
        dot.textContent = (e.time ? e.time.slice(0,5)+' ' : '') + e.name;
        cell.appendChild(dot);
      });
      if ((evByDay[d]||[]).length > 2) {
        const more = document.createElement('div');
        more.className = 'ev-dot';
        more.style.opacity = '0.5';
        more.style.fontSize = '9px';
        more.textContent = `+${evByDay[d].length-2}`;
        cell.appendChild(more);
      }
      cell.onclick = () => openDetail(ds, d);
      grid.appendChild(cell);
    }

    // Next month leading
    const trailing = (first+days)%7===0 ? 0 : 7-(first+days)%7;
    for (let i=1; i<=trailing; i++) {
      const c = document.createElement('div');
      c.className = 'day-cell other-month';
      c.innerHTML = `<div class="day-num">${i}</div>`;
      grid.appendChild(c);
    }

    renderSidebar();
  }

  function changeMonth(dir) {
    curMonth += dir;
    if (curMonth < 0)  { curMonth = 11; curYear--; }
    if (curMonth > 11) { curMonth = 0;  curYear++; }
    renderCalendar();
  }

  // ── Sidebar ──
  function renderSidebar() {
    const ts = todayStr();

    // Upcoming
    const upEl = document.getElementById('upcoming-list');
    upEl.innerHTML = '';
    const upcoming = events.filter(e => e.date >= ts).sort((a,b) => a.date.localeCompare(b.date)).slice(0,6);
    if (upcoming.length === 0) {
      upEl.innerHTML = '<div class="empty-msg">No upcoming events</div>';
    } else {
      upcoming.forEach(e => {
        const row = document.createElement('div');
        row.className = 'upcoming-row';
        const [,m,d] = e.date.split('-');
        row.innerHTML = `
          <div class="up-date">${SHORT_MONTHS[parseInt(m)-1]} ${parseInt(d)}</div>
          <div>
            <div class="up-name">${e.name}</div>
            <span class="up-tag ${e.cat === 'sports' ? 'pill-sports' : e.cat === 'classroom' ? 'pill-classroom' : 'pill-personal'}">
              ${e.cat === 'sports' ? 'Sports You' : e.cat === 'classroom' ? 'Classroom' : 'Personal'}
            </span>
          </div>`;
        upEl.appendChild(row);
      });
    }

    // Reminders
    const remEl = document.getElementById('reminder-list');
    remEl.innerHTML = '';
    const reminders = events.filter(e => {
      if (e.remind === 'none') return false;
      const diff = (new Date(e.date+'T00:00:00') - today) / 86400000;
      if (e.remind === '30min') return diff >= 0 && diff <= 0.03;
      if (e.remind === '1day')  return diff >= 0 && diff <= 1;
      if (e.remind === '2days') return diff >= 0 && diff <= 2;
      if (e.remind === '1week') return diff >= 0 && diff <= 7;
      return false;
    });
    if (reminders.length === 0) {
      remEl.innerHTML = '<div class="empty-msg">No active reminders</div>';
    } else {
      reminders.forEach(e => {
        const row = document.createElement('div');
        row.className = 'reminder-row';
        const [,m,d] = e.date.split('-');
        row.innerHTML = `
          <div class="remind-icon">🔔</div>
          <div>
            <div class="remind-name">${e.name}</div>
            <div class="remind-meta">${SHORT_MONTHS[parseInt(m)-1]} ${parseInt(d)} · ${e.remind} before</div>
          </div>`;
        remEl.appendChild(row);
      });
    }

    // Stats
    const weekEnd = new Date(today);
    weekEnd.setDate(today.getDate() + 7);
    const ws = dateStr(weekEnd);
    document.getElementById('stat-practices').textContent = events.filter(e => e.cat==='sports' && e.date>=ts).length;
    document.getElementById('stat-due').textContent       = events.filter(e => e.cat==='classroom' && e.date>=ts).length;
    document.getElementById('stat-week').textContent      = events.filter(e => e.date>=ts && e.date<=ws).length;
  }

  // ── Detail sheet ──
  function openDetail(ds, d) {
    selectedDate = ds;
    document.getElementById('detail-date-label').textContent = `${MONTHS[curMonth]} ${d}, ${curYear}`;
    const container = document.getElementById('detail-events');
    container.innerHTML = '';
    const dayEvs = events.filter(e => e.date === ds).sort((a,b) => a.time.localeCompare(b.time));
    if (dayEvs.length === 0) {
      container.innerHTML = '<div class="detail-ev"><div class="detail-ev-meta">No events this day</div></div>';
    } else {
      dayEvs.forEach(e => {
        const div = document.createElement('div');
        div.className = 'detail-ev';
        const lbl = e.cat==='sports' ? 'Sports You' : e.cat==='classroom' ? 'Classroom' : 'Personal';
        div.innerHTML = `
          <div class="detail-ev-name">${e.name}</div>
          <div class="detail-ev-meta">${e.time ? e.time+' · ' : ''}<span class="up-tag ${e.cat==='sports'?'pill-sports':e.cat==='classroom'?'pill-classroom':'pill-personal'}">${lbl}</span>${e.notes ? ' · '+e.notes : ''}</div>
          ${e.remind!=='none' ? `<div class="detail-ev-meta" style="margin-top:3px">🔔 Reminder: ${e.remind} before</div>` : ''}
          <button class="detail-del" onclick="App.deleteEvent(${e.id})">Remove</button>`;
        container.appendChild(div);
      });
    }
    document.getElementById('detail-overlay').classList.remove('hidden');
    document.getElementById('detail-sheet').classList.remove('hidden');
  }

  function closeDetail() {
    document.getElementById('detail-overlay').classList.add('hidden');
    document.getElementById('detail-sheet').classList.add('hidden');
  }

  function openAddFromDetail() {
    closeDetail();
    openAddEvent(selectedDate);
  }

  // ── Add Event ──
  function openAddEvent(ds) {
    document.getElementById('ev-name').value = '';
    document.getElementById('ev-date').value = ds || '';
    document.getElementById('ev-time').value = '';
    document.getElementById('ev-cat').value = 'personal';
    document.getElementById('ev-remind').value = 'none';
    document.getElementById('ev-notes').value = '';
    document.getElementById('add-overlay').classList.remove('hidden');
    document.getElementById('add-sheet').classList.remove('hidden');
    setTimeout(() => document.getElementById('ev-name').focus(), 300);
  }

  function closeAdd() {
    document.getElementById('add-overlay').classList.add('hidden');
    document.getElementById('add-sheet').classList.add('hidden');
  }

  function saveEvent() {
    const name = document.getElementById('ev-name').value.trim();
    const date = document.getElementById('ev-date').value;
    if (!name || !date) { alert('Please enter a name and date.'); return; }
    const ev = {
      id: nextId++,
      name,
      date,
      time: document.getElementById('ev-time').value,
      cat:  document.getElementById('ev-cat').value,
      remind: document.getElementById('ev-remind').value,
      notes: document.getElementById('ev-notes').value,
    };
    events.push(ev);
    persist();
    scheduleNotification(ev);
    closeAdd();
    renderCalendar();
  }

  function deleteEvent(id) {
    events = events.filter(e => e.id !== id);
    persist();
    if (selectedDate) openDetail(selectedDate, parseInt(selectedDate.split('-')[2]));
    renderCalendar();
  }

  // ── Settings ──
  function openSettings() {
    document.getElementById('settings-name').value = userName;
    const saved = localStorage.getItem('schedulr_ical') || '';
    document.getElementById('ical-url').value = saved;
    updateNotifButton();
    document.getElementById('settings-overlay').classList.remove('hidden');
    document.getElementById('settings-sheet').classList.remove('hidden');
  }

  function closeSettings() {
    document.getElementById('settings-overlay').classList.add('hidden');
    document.getElementById('settings-sheet').classList.add('hidden');
  }

  function saveName() {
    const val = document.getElementById('settings-name').value.trim();
    if (!val) return;
    userName = val;
    localStorage.setItem('schedulr_name', userName);
    updateGreeting();
    closeSettings();
  }

  // ── iCal / Sports You ──
  function saveIcal() {
    const url = document.getElementById('ical-url').value.trim();
    const status = document.getElementById('ical-status');
    if (!url) { status.textContent = 'Please paste a URL first.'; status.className = 'connect-status error'; return; }
    localStorage.setItem('schedulr_ical', url);
    status.textContent = '✓ URL saved! Syncing your sportsYou schedule...';
    status.className = 'connect-status';
    fetchIcal(url);
  }

  async function fetchIcal(url) {
    const status = document.getElementById('ical-status');
    try {
      // Convert webcal:// to https://
      const fetchUrl = url.replace(/^webcal:\/\//i, 'https://');
      // Use a CORS proxy for the iCal fetch
      const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(fetchUrl)}`;
      const res = await fetch(proxyUrl);
      const data = await res.json();
      if (!data.contents) throw new Error('No data returned');
      const parsed = parseIcal(data.contents);
      // Remove old sports events and replace with fresh ones
      events = events.filter(e => e.cat !== 'sports' || e.source !== 'ical');
      parsed.forEach(e => events.push(e));
      persist();
      renderCalendar();
      status.textContent = `✓ Synced ${parsed.length} event(s) from sportsYou!`;
    } catch (err) {
      status.textContent = '⚠ Could not sync. Check the URL and try again.';
      status.className = 'connect-status error';
    }
  }

  function parseIcal(text) {
    const evs = [];
    const blocks = text.split('BEGIN:VEVENT');
    blocks.slice(1).forEach(block => {
      const get = (key) => {
        const match = block.match(new RegExp(`${key}[^:]*:(.+)`));
        return match ? match[1].trim() : '';
      };
      const dtstart = get('DTSTART');
      const summary = get('SUMMARY');
      if (!dtstart || !summary) return;
      const date = dtstart.slice(0,8);
      const formatted = `${date.slice(0,4)}-${date.slice(4,6)}-${date.slice(6,8)}`;
      let time = '';
      if (dtstart.length > 8) {
        const t = dtstart.slice(9,15);
        time = `${t.slice(0,2)}:${t.slice(2,4)}`;
      }
      evs.push({ id: nextId++, name: summary, date: formatted, time, cat: 'sports', remind: '1day', notes: '', source: 'ical' });
    });
    return evs;
  }

  // ── Google Classroom ──
  function connectGoogle() {
    const status = document.getElementById('google-status');
    // ── DEVELOPER NOTE ──
    // To enable real Google Classroom sync, follow these steps:
    // 1. Go to https://console.cloud.google.com
    // 2. Create a new project called "Schedulr"
    // 3. Enable the "Google Classroom API"
    // 4. Create OAuth 2.0 credentials (Web Application type)
    // 5. Add your deployed URL to "Authorized JavaScript origins"
    // 6. Replace YOUR_GOOGLE_CLIENT_ID below with your actual Client ID
    // 7. Uncomment the Google Sign-In code below
    //
    // const CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID';
    // const SCOPE = 'https://www.googleapis.com/auth/classroom.courses.readonly https://www.googleapis.com/auth/classroom.coursework.me.readonly';
    // const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${CLIENT_ID}&redirect_uri=${encodeURIComponent(window.location.origin+'/auth/google')}&response_type=token&scope=${encodeURIComponent(SCOPE)}`;
    // window.location.href = authUrl;

    status.textContent = '⚙ Google Classroom sync requires setup. See SETUP.md for instructions.';
    status.className = 'connect-status';
  }

  async function fetchClassroomAssignments(accessToken) {
    try {
      // Fetch courses
      const coursesRes = await fetch('https://classroom.googleapis.com/v1/courses?courseStates=ACTIVE', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const coursesData = await coursesRes.json();
      const courses = coursesData.courses || [];

      // Fetch coursework for each course
      for (const course of courses) {
        const cwRes = await fetch(`https://classroom.googleapis.com/v1/courses/${course.id}/courseWork`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        const cwData = await cwRes.json();
        const works = cwData.courseWork || [];
        works.forEach(work => {
          if (!work.dueDate) return;
          const { year, month, day } = work.dueDate;
          const date = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
          events.push({
            id: nextId++,
            name: work.title,
            date,
            time: '',
            cat: 'classroom',
            remind: '1day',
            notes: course.name,
            source: 'google'
          });
        });
      }
      persist();
      renderCalendar();
    } catch (err) {
      console.error('Google Classroom fetch error:', err);
    }
  }

  // ── Notifications ──
  function updateNotifButton() {
    const btn = document.getElementById('notif-btn');
    const status = document.getElementById('notif-status');
    if (!btn) return;
    if (!('Notification' in window)) {
      btn.textContent = 'Not supported on this browser';
      btn.disabled = true;
      return;
    }
    if (Notification.permission === 'granted') {
      btn.textContent = '✓ Notifications enabled';
      btn.style.background = '#1D9E75';
      if (status) status.textContent = 'You will receive event reminders.';
    } else if (Notification.permission === 'denied') {
      btn.textContent = 'Notifications blocked';
      btn.disabled = true;
      if (status) { status.textContent = 'Enable in your browser/phone settings.'; status.className = 'connect-status error'; }
    }
  }

  async function requestNotifications() {
    if (!('Notification' in window)) return;
    const perm = await Notification.requestPermission();
    updateNotifButton();
    if (perm === 'granted') {
      new Notification('Schedulr', { body: "You'll get reminders for your events!", icon: '/icons/icon-192.png' });
    }
  }

  function scheduleNotification(ev) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    if (ev.remind === 'none') return;
    const evDate = new Date(ev.date + 'T' + (ev.time || '08:00'));
    const offset = ev.remind === '30min' ? 30*60000 : ev.remind === '1day' ? 86400000 : ev.remind === '2days' ? 2*86400000 : 7*86400000;
    const fireAt = evDate.getTime() - offset;
    const delay = fireAt - Date.now();
    if (delay > 0 && delay < 7*24*60*60*1000) {
      setTimeout(() => {
        new Notification(`Upcoming: ${ev.name}`, { body: `${ev.remind} reminder · ${ev.date}`, icon: '/icons/icon-192.png' });
      }, delay);
    }
  }

  // ── Helpers ──
  function todayStr() {
    return `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  }
  function dateStr(d) {
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function persist() {
    localStorage.setItem('schedulr_events', JSON.stringify(events));
    localStorage.setItem('schedulr_nextid', String(nextId));
  }

  // ── Public API ──
  return { init, confirmName, showApp, setTheme, setCustomColor, changeMonth, openDetail, closeDetail, openAddFromDetail, openAddEvent, closeAdd, saveEvent, deleteEvent, openSettings, closeSettings, saveName, saveIcal, connectGoogle, requestNotifications };

})();

// ── Service Worker (PWA offline support) ──
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(err => console.warn('SW:', err));
}

// ── Boot ──
document.addEventListener('DOMContentLoaded', App.init);
